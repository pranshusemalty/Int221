-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 10, 2020 at 05:22 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_04_07_084754_transactions', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `Remaning` int(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `userid`, `email`, `amount`, `created_at`, `Remaning`, `updated_at`) VALUES
(107, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '600', '2020-04-09 23:51:42', 13000, '2020-04-09 23:51:42'),
(106, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '10000', '2020-04-09 14:04:35', 13600, '2020-04-09 14:04:35'),
(105, 'pranshu.semalty@gmail.com', 'pranshu.semalty@gmail.com', '10000', '2020-04-09 14:03:00', 13600, '2020-04-09 14:03:00'),
(104, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '1400', '2020-04-09 14:02:49', 23600, '2020-04-09 14:02:49'),
(103, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '1400', '2020-04-09 14:02:17', 25000, '2020-04-09 14:02:17'),
(102, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '100', '2020-04-09 14:02:01', 26400, '2020-04-09 14:02:01'),
(99, 'drew@gmail.com', 'pranshu.semalty@gmail.com', '1400', '2020-04-09 12:39:33', 24266, '2020-04-09 12:39:33'),
(100, 'drew@gmail.com', 'pranshu.semalty@gmail.com', '1400', '2020-04-09 12:39:47', 22866, '2020-04-09 12:39:47'),
(101, 'pranshu.semalty@gmail.com', 'drew@gmail.com', '30000', '2020-04-09 12:42:42', 26500, '2020-04-09 12:42:42');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Account` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Branch` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` int(100) NOT NULL DEFAULT '1200',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `Account`, `Branch`, `balance`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Lifetime Trends', 'pranshu.semalty@gmail.com', '$2y$10$s13Ty0so1IWQZoMa5mcnkuYIXzl9bVGsx7.hk0PRH10GzGN/RWl/O', '96643403', 'dehradun', 13000, 'C92KcNlCRbqBf1MsT6wxfTbTULws7mSTFQvidvVJBrN02x9cA5saLJyWAj2G', '2020-04-07 03:20:41', '2020-04-07 03:20:41'),
(3, 'Drew Taggart', 'drew@gmail.com', '$2y$10$vOEyPYMI0ukuthwpYGrbE.HVJINTS/eektn0z5DJfOxiVTKrnkStu', '53306732', 'los angles', 66366, 'LSYV8r51ODUJgcd5jRV5X9lbbyO0VVtKQui0SGmPoRokCrKvOMvHVE5vAYdR', '2020-04-09 08:30:09', '2020-04-09 08:30:09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
