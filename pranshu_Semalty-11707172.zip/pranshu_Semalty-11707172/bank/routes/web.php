<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/accountbalance', function(){
    return view('accountbalance');
});

Route::get('/profile', function(){
    return view('profile');
});
//Route::resource('transferfund','pagescontroller');
Route::resource('mytransaction','pagescontroller');
Route::get('/transfer',function(){
    return view('transfer');
});
Route::post('transfernow','pagescontroller@create');
Route::get('history','historycontroller@index');
Route::get('/reward',function(){
    return view('reward');
});