 
 <?php if(session('status')): ?>
 <div class="alert alert-success">
     <?php echo e(session('status')); ?>

 </div>
<?php endif; ?>   
 



<?php $__env->startSection('content'); ?>
<div class="well"><a href="/home">Back</a></div>
<div class="container">
    <div class="row ">
   
         <div class="col-lg-1 well ">
            Trans_id
         </div> 
         <div class="col-lg-3 well ">
            Reciever's Email
        </div> 
        <div class="col-lg-2 well ">
            Reciever Account
         </div>   
        <div class="col-lg-2 well ">
             Amount
        </div>  
        <div class="col-lg-2 well ">
            Remaining
         </div>  
        
        <div class="col-lg-2 well ">
           Date
        </div>               
 
     
    </div>

</div>

<?php if($funds): ?>
<?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
<div class="container">
    <div class="row ">
   
         <div class="col-lg-1 panel ">
            <?php echo e($fund->id); ?>

         </div> 
         <div class="col-lg-3 panel ">
            <?php echo e($fund->email); ?>

        </div> 
        <div class="col-lg-2 panel ">
            <?php echo e($fund->Account); ?>

        </div>   
        <div class="col-lg-2 panel ">
            <?php echo e($fund->amount); ?>

        </div>  
        <div class="col-lg-2 panel ">
            <?php echo e($fund->Remaning); ?>

        </div>  
      
        <div class="col-lg-2 panel ">
            <?php echo e($fund->created_at); ?>

        </div>                
 
     
    </div>

</div>

    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>