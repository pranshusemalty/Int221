<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>





<?php $__env->startSection('content'); ?>
     <div class="well"><a href="/home">Back</a></div>
<div class="container">
    <div class="row ">
   
         <div class="col-lg-12 panel ">
            <pre> 
                <div style="font-size:150%;">
            Name&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:     <?php echo e(Auth::user()->name); ?>

            Account&nbsp&nbsp&nbsp&nbsp&nbsp:     <?php echo e(Auth::user()->Account); ?>

            Branch&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:     <?php echo e(Auth::user()->Branch); ?>

            Email&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:     <?php echo e(Auth::user()->email); ?>

            Created on&nbsp&nbsp:     <?php echo e(Auth::user()->created_at); ?>

                 </div>

                 
           </pre>
         </div>
         
            






         </div>              
 
     
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>