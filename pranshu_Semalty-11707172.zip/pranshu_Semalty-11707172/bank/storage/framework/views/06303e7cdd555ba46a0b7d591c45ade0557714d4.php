<?php if(session('status')): ?>
<div class="alert alert-success">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>




<?php $__env->startSection('content'); ?>
<br><br><br><br>
      <div class="container" style="width:30%;">
           <!-- Default form login -->
<form class="text-center border border-light p-5" action="/transfernow" method="POST">
    <?php echo e(csrf_field()); ?>

    <p class="h4 mb-4">Transfer Fund</p>

    <!-- Email -->
    <input type="email"  name="email" class="form-control mb-4" placeholder="E-mail">
<br>
    <!-- Password -->
    <input type="text"  name="amount" class="form-control mb-4" placeholder="Amount">
    <input type="hidden" name="userid" value="<?php echo e(Auth::user()->email); ?>">

    <div class="d-flex justify-content-around">
        <div>
            
        </div>
        <br><br>
    </div>

    <!-- Sign in button -->
    <button class="btn btn-primary" type="submit">Transfer Now</button>

    

    <!-- Social login -->
     

    <a href="#" class="mx-2" role="button"><i class="fab fa-facebook-f light-blue-text"></i></a>
    <a href="#" class="mx-2" role="button"><i class="fab fa-twitter light-blue-text"></i></a>
    <a href="#" class="mx-2" role="button"><i class="fab fa-linkedin-in light-blue-text"></i></a>
    <a href="#" class="mx-2" role="button"><i class="fab fa-github light-blue-text"></i></a>

</form>
 
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>