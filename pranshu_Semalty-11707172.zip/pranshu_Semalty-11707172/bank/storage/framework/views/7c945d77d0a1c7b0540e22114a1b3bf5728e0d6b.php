<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome  <?php echo e(Auth::user()->name); ?></div>

                
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row ">
    <div class="col-lg-4">
             <div class="row panel panel-default">
                 <br><br><br>
                 
                 <div class="col-lg-12 border">
                                <div class="well "><a href="/accountbalance"style="text-decoration:none;">Account Balance</a> </div>
                 </div>
                 <br><br>
                 <div class="col-lg-12">
                                <div class="well"><a href="/history" style="text-decoration:none;">Transaction History</a> </div>       
                 </div>
                 <div class="col-lg-12">
                    <div class="well"> <a href="/profile" style="text-decoration:none;">Profile</a> </div>       
                 </div>
                 <div class="col-lg-12">
                    <div class="well"> <a href="/transfer" style="text-decoration:none;">Transfer Fund</a> </div>       
                 </div>
                 <div class="col-lg-12">
                    <div class="well"> <a href="/reward" style="text-decoration:none;">MyRewardz</a> </div>       
                 </div>
                 
            </div>
    </div>
    <div class="col-lg-8">
        <div class="">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
           <div class="col-lg-8 panel "><br><br>
                  <div class="row ">
                          <div class="col-lg-12 " style="background-color:#474747;"><br>
                              <div style="color:white;" >Transaction</div><br>
                          </div>
                           <br>
                          <div class="col-lg-12 " style="background-color:#ebebeb;"><br>
                            <h2>Account No:&nbsp&nbsp<?php echo e(Auth::user()->Account); ?></h2><br>
                          </div>
                          <div class="col-lg-12 " style="background-color:#ebebeb;"><br>
                            <h2 >Branch:&nbsp&nbsp<?php echo e(Auth::user()->Branch); ?></h2><br>
                          </div>
                          <div class="col-lg-12 " style="background-color:#ebebeb;"><br>
                            <h2> Available balance: <?php echo e(Auth::user()->balance); ?></h2> <br>
                          </div>
                          <a href="mytransaction">(Click here to view last 5 transaction)</a>

                      
                  </div>

           </div>
            
        </div>
    </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>