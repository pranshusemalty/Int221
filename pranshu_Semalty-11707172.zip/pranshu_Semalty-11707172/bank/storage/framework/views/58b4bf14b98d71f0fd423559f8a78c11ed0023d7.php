<?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($fund->all()); ?>

    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>