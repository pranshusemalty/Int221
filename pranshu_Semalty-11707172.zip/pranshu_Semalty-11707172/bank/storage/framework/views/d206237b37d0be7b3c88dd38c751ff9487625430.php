<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
        
        </style>
    </head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                       <style>
                           body
                           {
                            background-image: url('<?php echo e(asset('pnb.jpg')); ?>');"
                           }
                       </style>
                         <div  style="padding-left:46%;padding-top:15%;">
                              <a href="<?php echo e(url('/login')); ?>" style="color:black;"><button  class="btn btn-primary " >lOgin</button></a>
                             
                                <a href="<?php echo e(url('/register')); ?>" style="color:black;"> <button class="btn btn-primary " >Register</button></a>
                               


                         </div>
                         <p   style="padding-left:40%;font-size:1000%;color:white;font-family:'Franklin Gothic Medium';">P&nbspN&nbspB</p>
                         <p style="padding-left:45%;color:white;font-family:'Franklin Gothic ';">The name you can bank upon</p>
                         
                    <?php endif; ?>
                </div>
            <?php endif; ?>
 
        </div>
    </body>
</html>

