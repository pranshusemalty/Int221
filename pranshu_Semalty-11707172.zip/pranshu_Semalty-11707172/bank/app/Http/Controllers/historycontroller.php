<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\user;
use DB;
use Auth;

class historycontroller extends Controller
{
    public function index()
    {
        $a=Auth::user()->email; 
       // $fund=\App\transaction::all();
       
       // return view('viewtransaction')->with('funds',$fund->take(5));
       
       $funds = User::join('transactions', 'transactions.userid', '=', 'users.email')
       ->select('users.*','transactions.*')->where('transactions.userid', '=', $a)
        ->get();
     return view('history', compact('funds'));

    }
}
