<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\user;
use DB;
use Auth;

class pagescontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $a=Auth::user()->email; 
       // $fund=\App\transaction::all();
       
       // return view('viewtransaction')->with('funds',$fund->take(5));
       
       $funds = User::join('transactions', 'transactions.userid', '=', 'users.email')
       ->select('users.*','transactions.*')->where('transactions.userid', '=', $a)->take(5)
        ->get();
     return view('viewtransaction', compact('funds'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create( Request $req)
    {
        $a=Auth::user()->balance; 
        $b=Auth::user()->email; 


        $email=$req->email;
        $amount=$req->amount;
        $id=$req->userid;
        $p = new \App\transaction;
        

        $p->email=$email;
        $p->amount=$amount;
        $p->userid=$id;
        $p->save();
        $q= new \App\User;
        $r=$a-$amount;
       DB::table('users')->where("users.email", '=', $b)
       ->update(['users.balance'=> $r]);
        //getting

       
       $user = User::where('email', '=',$email)->firstOrFail();
        
        $recieverfunds= $user->balance;
        
    $finalfund=$recieverfunds+$amount;
    //
    $p->email=$email;
    $p->amount=$amount;
    $p->userid=$id;
    $p->Remaning=$r;
    $p->save();
        
        

       DB::table('users')->where("users.email", '=', $email)
       ->update(['users.balance'=> $finalfund]);

        return view('success');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
