<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
        
        </style>
    </head>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <body>
        
            
                 
                    
                       <style>
                           body
                           {
                           background-image: url('{{ asset('rewards.jpg')}}');
                           
                           }
                       </style>
                          <div class="container" style="padding-top:20%;">
                              <div class="well">
                                  <p class="well">Now get Rewards point for your Purchase.Contact Nearest Branch</p>     
                              </div>

                          </div>
                         
                    
               
    </body>
</html>

