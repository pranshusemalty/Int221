@extends('layouts.app')

@section('content')
  <div class="well"><a href="/home">Back</a></div>
<div class="container">
    <div class="row ">
  
    <div class="col-lg-12">
        <div class="">
            @if (session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                </div>
            @endif
           <div class="col-lg-12 panel "><br><br>
                  <div class="row ">
                           
                  <div style="text-align:center;font-size:200%;">Account Balance </div>
                  <div style="text-align:center;font-size:260%;">{{Auth::user()->balance}} </div>
                  <br><br><br><br>
                      
                  </div>

           </div>
            
        </div>
    </div>
    </div>

</div>
@endsection
