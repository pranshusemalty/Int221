 
 @if (session('status'))
 <div class="alert alert-success">
     {{ session('status') }}
 </div>
@endif   
 

@extends('layouts.app')

@section('content')
<div class="well"><a href="/home">Back</a></div>
<div class="container">
    <div class="row ">
   
         <div class="col-lg-1 well ">
            Trans_id
         </div> 
         <div class="col-lg-3 well ">
            Reciever's Email
        </div> 
        <div class="col-lg-2 well ">
            Reciever Account
         </div>   
        <div class="col-lg-2 well ">
             Amount
        </div>  
        <div class="col-lg-2 well ">
            Remaining
         </div>  
        
        <div class="col-lg-2 well ">
           Date
        </div>               
 
     
    </div>

</div>

@if($funds)
@foreach ($funds as $fund)
     
<div class="container">
    <div class="row ">
   
         <div class="col-lg-1 panel ">
            {{$fund->id}}
         </div> 
         <div class="col-lg-3 panel ">
            {{$fund->email}}
        </div> 
        <div class="col-lg-2 panel ">
            {{$fund->Account}}
        </div>   
        <div class="col-lg-2 panel ">
            {{$fund->amount}}
        </div>  
        <div class="col-lg-2 panel ">
            {{$fund->Remaning}}
        </div>  
      
        <div class="col-lg-2 panel ">
            {{$fund->created_at}}
        </div>                
 
     
    </div>

</div>

    
@endforeach
@endif
@endsection
